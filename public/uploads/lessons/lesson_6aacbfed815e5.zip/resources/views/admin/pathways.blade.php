@extends('layouts.app')

@section('title', 'Learning Pathways')

@section('content')
@include('components.authenticated-topbar', ['user' => $user])
<div class="pathway-admin">
    <div class="intro"><p>Admin configuration</p><h1>Learning pathways</h1><span>Create guided journeys, add courses, and set their sequence.</span></div>
    @if(session('success'))<div class="notice success">{{ session('success') }}</div>@endif
    @if($errors->any())<div class="notice error">{{ $errors->first() }}</div>@endif
    <form method="POST" action="{{ route('admin.pathways.store') }}" class="pathway-form">
        @csrf <h2>Create a pathway</h2><div class="form-grid"><label>Name<input name="name" required placeholder="e.g. Full Stack Web Development"></label><label>Description<input name="description" placeholder="Short description"></label></div>
        <p class="section-label">Add and sequence courses</p><div class="sequence-list" data-sequence-list>@foreach($courses as $course)<div class="sequence-item"><label><input type="checkbox" name="course_ids[]" value="{{ $course->id }}"><span>{{ $course->title }}</span></label><div><button type="button" data-up>↑</button><button type="button" data-down>↓</button></div></div>@endforeach</div>
        <button class="primary">Create pathway</button>
    </form>
    <div class="existing-list">@forelse($pathways as $pathway)
        @php $selected = $pathway->courses->pluck('id')->all(); $ordered = $pathway->courses; $remaining = $courses->reject(fn($course) => in_array($course->id, $selected, true)); @endphp
        <form method="POST" action="{{ route('admin.pathways.update', $pathway->id) }}" class="pathway-form">@csrf @method('PATCH')
            <div class="form-grid"><label>Name<input name="name" value="{{ $pathway->name }}" required></label><label>Description<input name="description" value="{{ $pathway->description }}"></label><label class="active"><input type="checkbox" name="is_active" value="1" @checked($pathway->is_active)> Active</label></div>
            <p class="section-label">Course sequence</p><div class="sequence-list" data-sequence-list>@foreach($ordered as $course)<div class="sequence-item selected"><label><input type="checkbox" name="course_ids[]" value="{{ $course->id }}" checked><span>{{ $loop->iteration }}. {{ $course->title }}</span></label><div><button type="button" data-up>↑</button><button type="button" data-down>↓</button></div></div>@endforeach @foreach($remaining as $course)<div class="sequence-item"><label><input type="checkbox" name="course_ids[]" value="{{ $course->id }}"><span>{{ $course->title }}</span></label><div><button type="button" data-up>↑</button><button type="button" data-down>↓</button></div></div>@endforeach</div>
            <button class="primary">Save changes</button>
        </form>
    @empty <div class="empty">No pathways yet.</div>@endforelse</div>
</div>
<style>
.pathway-admin{max-width:1080px;margin:0 auto;padding:42px 24px 80px;color:#101b49}.intro{margin-bottom:24px}.intro p{color:#b17800;font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.intro h1{font-size:38px;margin:8px 0}.intro span{color:#68758c}.notice{padding:12px 14px;border-radius:10px;margin-bottom:18px;font-size:13px;font-weight:700}.notice.success{background:#ecfdf3;color:#067647}.notice.error{background:#fff1f2;color:#b42318}.existing-list{display:grid;gap:18px}.pathway-form{background:#fff;border:1px solid #e2e8f3;border-radius:18px;padding:22px;box-shadow:0 12px 30px #0a1f6e0b}.pathway-form h2{font-size:20px;margin:0 0 16px}.form-grid{display:grid;grid-template-columns:1fr 2fr auto;gap:14px;align-items:end}.form-grid label{display:grid;gap:7px;color:#43516d;font-size:12px;font-weight:800}.form-grid input:not([type=checkbox]){padding:11px;border:1px solid #dce4f0;border-radius:9px;color:#17244d}.form-grid label.active{display:flex;align-items:center;gap:7px;padding-bottom:11px;white-space:nowrap}.section-label{font-size:13px;font-weight:800;margin:20px 0 9px}.sequence-list{display:grid;gap:7px}.sequence-item{display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid #e2e7f0;border-radius:10px;padding:9px 10px;background:#fbfcfe}.sequence-item.selected{background:#fff9e5;border-color:#e8c62b}.sequence-item label{display:flex;gap:10px;align-items:center;font-size:13px;color:#243252;font-weight:700}.sequence-item button{border:1px solid #dce4f0;border-radius:7px;background:#fff;color:#0a1f6e;cursor:pointer;padding:3px 8px;font-weight:800}.sequence-item button:hover{background:#eef3ff}.primary{margin-top:18px;border:0;border-radius:999px;padding:11px 18px;background:#0a1f6e;color:#fff;font-weight:800;cursor:pointer}.empty{padding:30px;background:#f7f9fc;border-radius:14px;color:#68758c}@media(max-width:700px){.form-grid{grid-template-columns:1fr}.form-grid label.active{padding-bottom:0}}
</style>
<script>
(function(){document.querySelectorAll('[data-sequence-list]').forEach(function(list){list.addEventListener('click',function(e){var button=e.target.closest('button');if(!button)return;var item=button.closest('.sequence-item');if(button.hasAttribute('data-up')&&item.previousElementSibling)list.insertBefore(item,item.previousElementSibling);if(button.hasAttribute('data-down')&&item.nextElementSibling)list.insertBefore(item.nextElementSibling,item);list.querySelectorAll('.sequence-item.selected span').forEach(function(span,i){span.textContent=(i+1)+'. '+span.textContent.replace(/^\d+\.\s*/,'' )});});});})();
</script>
@endsection
