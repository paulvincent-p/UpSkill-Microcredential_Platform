<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            if (! Schema::hasColumn('users', 'onboarding_role')) {
                $table->string('onboarding_role')->nullable()->after('career_goal');
            }
            if (! Schema::hasColumn('users', 'interest_subjects')) {
                $table->json('interest_subjects')->nullable()->after('onboarding_role');
            }
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            foreach (['onboarding_role', 'interest_subjects'] as $column) {
                if (Schema::hasColumn('users', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
