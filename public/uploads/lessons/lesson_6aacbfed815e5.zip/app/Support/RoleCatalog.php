<?php

namespace App\Support;

/**
 * Roles shown during onboarding. Each role points to subjects from the same
 * vocabulary used by the faculty "Subject is Related on" course picker.
 */
class RoleCatalog
{
    /** @var array<string, list<string>> */
    public const ROLES = [
        'Software Developer' => ['Programming', 'Algorithms', 'Software', 'Coding', 'Databases', 'Web Development'],
        'Data Analyst' => ['Statistics', 'Mathematics', 'Probability', 'Quantitative Analysis', 'Databases', 'Programming'],
        'Cybersecurity Specialist' => ['Cybersecurity', 'Networking', 'Systems', 'Infrastructure', 'Logic'],
        'IT Support Specialist' => ['Tech Support', 'Hardware', 'Networking', 'Troubleshooting', 'Infrastructure'],
        'Project Manager' => ['Project Management', 'Leadership', 'Communication', 'Strategy', 'Resources'],
        'Financial Analyst' => ['Finance', 'Accounting', 'Statistics', 'Investments', 'Risk Management'],
        'Teacher / Educator' => ['Teaching', 'Pedagogy', 'Curriculum', 'Lesson Plans', 'Classroom Management'],
        'Hospitality Professional' => ['Hotels', 'Tourism', 'Customer Service', 'Event Planning', 'Restaurants'],
        'Public Service Professional' => ['Government', 'Policy', 'Leadership', 'Governance', 'Community'],
        'Healthcare / Nutrition Professional' => ['Health', 'Nutrition', 'Clinical Nutrition', 'Public Health', 'Meal Planning'],
        'Skilled Trades Professional' => ['Welding', 'Electrical Work', 'Automotive Servicing', 'Maintenance', 'Fabrication'],
        'I am exploring options' => [],
    ];

    public static function all(): array
    {
        return array_keys(self::ROLES);
    }

    public static function subjectsFor(?string $role): array
    {
        return self::ROLES[$role] ?? [];
    }

    public static function subjectMap(): array
    {
        return self::ROLES;
    }
}
