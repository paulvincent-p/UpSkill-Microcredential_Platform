import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author GEOFREY
 */
public class DBConnection {
         public static Connection connect() {
        try{
            Class .forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection
           (
                "jdbc:mysql://localhost:3306/inventdb", 
                "root",                                 
                "IanGeofrey2004"                         
            );
        }
        catch (ClassNotFoundException | SQLException e)
        {
            return null;
        }
         }
}